# BergaHallen KTM Server – Headless Quick Install 1.0.0-dev.5 r6

This release is intended for **Ubuntu Server 24.04 LTS amd64** and uses the same direct CLI installation flow that was field-tested during development. A `.deb` package is **not required** for headless installation.

## Quick install

```bash
unzip BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6.zip
cd BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6
bash verify-package.sh
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang en
```

Swedish:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang sv
```

The package includes the Server payload. If Docker is absent, Installer/Manager can provision and verify a compatible Docker installation in the Hybrid flow after final confirmation.

## Manager Web

After Server installation:

```bash
sudo bergahallen-ktm web setup --lang en
sudo bergahallen-ktm web status --lang en
```

Default Manager Web settings are LAN scope, HTTPS port 3011 and username `manager-admin`. Manager Web uses separate credentials from the KTM Server accounts.

## Platform support

- Ubuntu Server 24.04 LTS
- amd64/x86-64
- physical server or full VM
- LXC/CT/nested-container hosts are not officially supported

See the included `README.md` and `docs/` directory for full Swedish and English instructions.

**Development status:** this public package is a distribution wrapper around the frozen Installer/Manager `1.0.0-dev.5 / advanced-install.1-test-r6` baseline. It does not create a new engineering revision.

## Distribution revision 2

This public Headless wrapper restores `packaging/docker-sources.json` and the matching packaging manifest from the frozen r6 release. These files are required when a clean Ubuntu host has no Docker installation and Hybrid mode downloads the verified Docker payload after the user's final confirmation.

The Installer/Manager binary and embedded Server are unchanged from the field-verified frozen r6 baseline.

# Public distribution notice

This archive is a convenience distribution wrapper for BergaHallen KTM Installer/Manager `1.0.0-dev.5 / advanced-install.1-test-r6`.

It is intentionally separate from the active development and Project Control line. Creating or publishing this archive:

- does not create Installer/Manager r7;
- does not modify the frozen dev.5 component;
- does not alter future dev.6+ development decisions;
- does not rewrite the embedded release manifest;
- preserves the Installer/Manager runtime binary and embedded Server payload byte-for-byte from the frozen r6 baseline.

The wrapper adds only public-facing documentation, verification helpers and convenience launch scripts.

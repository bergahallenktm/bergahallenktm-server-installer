#!/usr/bin/env bash
set -euo pipefail
args=("$@")
if [[ ${#args[@]} -eq 0 ]]; then
  args=(--lang sv)
fi
if ! command -v bergahallen-ktm >/dev/null 2>&1; then
  echo "ERROR: bergahallen-ktm är inte installerad. Installera Servern först." >&2
  exit 1
fi
if [[ $(id -u) -eq 0 ]]; then
  exec bergahallen-ktm web setup "${args[@]}"
fi
exec sudo bergahallen-ktm web setup "${args[@]}"

# Offline Docker payload

Den här katalogen är den permanenta release-layouten för offline-Dockerpaket.

Källträdet innehåller inte tredjeparts-`.deb`-filer. Releasebyggaren fyller katalogen med:

```text
payload/docker/<distribution>/<version>/<architecture>/
├── docker-payload.json
└── packages/
    ├── containerd.io_....deb
    ├── docker-ce-cli_....deb
    ├── docker-ce_....deb
    ├── docker-buildx-plugin_....deb
    └── docker-compose-plugin_....deb
```

Bygg payloaden på en internetansluten releasebyggare:

```bash
go run ./cmd/docker-payload-builder -spec packaging/docker-sources.json -out payload/docker
```

`docker-payload.json` skapas först efter lyckad nedladdning och innehåller faktisk SHA-256 och filstorlek för varje paket. Slutanvändarens installerare gör ingen nätverksåtkomst i offline-läge och kräver att dessa checksums verifieras innan `dpkg --install` körs.

# BergaHallen KTM Server – Headless Quick Install

**Release:** BergaHallen KTM Suite `1.0.0-dev.5`  
**Installer/Manager:** `advanced-install.1-test-r6`  
**Server:** `1.0.0-dev.5` / API v1 / DB schema 21  
**Platform:** Ubuntu Server 24.04 LTS, amd64/x86-64  

Det här paketet är gjort för samma installationssätt som användes under utveckling och fälttest: packa upp ZIP-filen och kör Installer/Manager direkt från `bin/`. **Ingen `.deb`-installation behövs på en headless server.**

## Snabbstart – svenska

```bash
unzip BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6-dist.2.zip
cd BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6-dist.2
./verify-package.sh
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang sv
```

Alternativt:

```bash
bash install.sh --lang sv
```

Installationsguiden:

- kontrollerar Ubuntu/amd64/root och stoppar på LXC/CT/container-host;
- hittar LAN-IP automatiskt i Recommended-läget;
- installerar/verifierar Docker vid behov efter din slutliga bekräftelse;
- installerar den inbäddade BergaHallen KTM Server;
- skapar lokal HTTPS/CA-identitet;
- bootstrappar admin-kontot;
- verifierar health/meta;
- installerar CLI Manager permanent som `bergahallen-ktm`;
- visar en QR-kod för Android-pairing;
- skapar `~/BergaHallen-KTM-Installation.md` med valda inställningar och vanliga kommandon.

Efter installation:

```bash
sudo bergahallen-ktm doctor
sudo bergahallen-ktm verify-meta
sudo bergahallen-ktm status
```

För att aktivera den separata webbaserade Manager-delen:

```bash
sudo bergahallen-ktm web setup --lang sv
sudo bergahallen-ktm web status --lang sv
```

`web status` visar den exakta HTTPS-adressen och TLS-fingerprinten. Standard är LAN-scope, port `3011` och användarnamnet `manager-admin`. Manager Web använder **ett separat lösenord** från KTM Server-admin.

Se:

- `docs/INSTALLATION-SV.md` – komplett svensk installation
- `docs/MANAGER-WEB-SV.md` – aktivera och använda Manager Web
- `docs/COMMON-COMMANDS-SV.md` – drift, QR, loggar, backup och felsökning
- `docs/INSTALLATION-EN.md` / `docs/MANAGER-WEB-EN.md` – English instructions

## Important

This is a public distribution wrapper around the already frozen and field-verified Installer/Manager r6 artifacts. The embedded runtime binary, release manifest and Server payload are copied byte-for-byte from that baseline. This package does **not** create a new project revision and does not change the frozen project's status.

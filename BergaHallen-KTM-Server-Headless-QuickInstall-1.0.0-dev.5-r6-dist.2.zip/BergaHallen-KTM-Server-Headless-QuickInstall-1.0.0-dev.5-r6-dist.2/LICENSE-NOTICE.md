# License notice

No open-source license has been selected for this snapshot.

Public availability of source or binary artifacts does not by itself grant permission to copy, modify, redistribute, sublicense, or create derivative works beyond rights provided by applicable law.

If the project owner later selects an open-source license, this notice should be replaced by the chosen LICENSE file in a future public distribution snapshot. This publication-only notice does not modify the frozen engineering baseline.

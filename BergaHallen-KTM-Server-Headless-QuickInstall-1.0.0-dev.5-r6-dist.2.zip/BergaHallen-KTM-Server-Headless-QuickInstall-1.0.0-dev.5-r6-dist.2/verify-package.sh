#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

required=(
  "bin/bergahallen-ktm-linux-amd64"
  "release-manifest.json"
  "packaging/docker-sources.json"
  "packaging/release-manifest.json"
  "payload/server-complete/current-server-complete.zip"
  "payload/server-complete/SHA256SUMS.txt"
)

for f in "${required[@]}"; do
  if [[ ! -f "$f" ]]; then
    echo "ERROR: required runtime file is missing: $f" >&2
    exit 1
  fi
done

sha256sum -c SHA256SUMS.txt

echo "PASS: Headless QuickInstall package is complete and checksums are valid."

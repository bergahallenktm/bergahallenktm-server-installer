# Public distribution package revision

This archive is **distribution revision 2** of the Headless QuickInstall wrapper for the frozen BergaHallen KTM Installer/Manager baseline:

- Suite: `1.0.0-dev.5`
- Installer/Manager component revision: `advanced-install.1-test-r6`
- Project status of that component: **FROZEN / unchanged**

Distribution revision 2 does **not** modify or rebuild the frozen Installer/Manager binary or embedded Server package.

It corrects the public wrapper by restoring the runtime file `packaging/docker-sources.json` (and its matching packaging manifest) from the byte-exact frozen r6 package. The Hybrid first-install flow requires this source specification when Docker is absent and the installer must obtain the verified Docker payload after final confirmation.

This is a packaging/distribution correction only. It does not create Installer/Manager r7 and does not alter Project Control status or future development.

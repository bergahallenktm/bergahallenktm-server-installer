# Manager Web – enable and use

The CLI Manager is installed automatically during Server installation. Manager Web is an optional, separate HTTPS management service with separate credentials from KTM Server/player accounts.

Enable it after the Server installation has completed:

```bash
sudo bergahallen-ktm web setup --lang en
```

Defaults:

- network scope: `lan`
- port: `3011`
- username: `manager-admin`
- session: 480 minutes
- local self-signed HTTPS certificate

You will be prompted twice for a separate Manager Web password. The systemd service is enabled for autostart.

Show the exact URL and TLS fingerprint:

```bash
sudo bergahallen-ktm web status --lang en
```

Open one of the listed `Web UI:` URLs from a machine on the same LAN. A browser certificate warning is expected for the local self-signed certificate; compare the SHA-256 fingerprint with `web status` before continuing.

If a host firewall is enabled, TCP/3011 may need to be allowed from your LAN. Do not expose Manager Web directly to the Internet.

Service controls:

```bash
sudo bergahallen-ktm web stop --lang en
sudo bergahallen-ktm web start --lang en
sudo bergahallen-ktm web restart --lang en
sudo bergahallen-ktm web password --lang en
sudo bergahallen-ktm web repair --lang en
```

Custom first-time setup examples:

```bash
sudo bergahallen-ktm web setup --port 8443 --lang en
sudo bergahallen-ktm web setup --scope localhost --lang en
sudo bergahallen-ktm web setup --username my-manager --lang en
```

# Installation – Ubuntu Server 24.04 headless

## 1. Krav

- Ubuntu Server **24.04 LTS**
- amd64 / x86-64
- fysisk Linuxserver eller full VM
- `sudo`/root-behörighet
- nätverksanslutning till ditt lokala LAN

**LXC/CT, Docker/Podman-container som värd och andra nested container-hosts stöds inte officiellt.** Installeraren stoppar tidigt om en sådan miljö upptäcks.

För Hybrid-installation kan internet behövas vid första körningen om Docker eller dess Ubuntu-beroenden saknas. Inga ytterligare BergaHallen KTM-serverfiler behöver hämtas separat; Server-payloaden finns i detta paket.

## 2. Packa upp paketet

Kopiera ZIP-filen till servern och kör exempelvis:

```bash
sudo apt update
sudo apt install -y unzip
unzip BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6.zip
cd BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6
```

Verifiera gärna paketets interna checksummor:

```bash
bash verify-package.sh
```

## 3. Recommended installation

Detta är rekommenderat för de flesta användare:

```bash
./verify-package.sh

sudo ./bin/bergahallen-ktm-linux-amd64 install --lang sv
```

Samma start kan göras via hjälp-scriptet:

```bash
bash install.sh --lang sv
```

Recommended väljer säkra standardvärden och använder LAN-IP som primär HTTPS-endpoint. DNS och mDNS behövs inte.

Under installationen får du:

1. systemkontroll;
2. automatiskt vald LAN-adress;
3. Docker-kontroll och, vid behov, erbjudande om managed Docker-installation;
4. val av KTM-adminlösenord;
5. en sammanfattning innan några systemändringar görs;
6. Server-installation och första start;
7. TLS/CA och säker Server-identitet;
8. terminal-QR för Android-appen.

**Systemändringar startar inte förrän du svarar Ja på den slutliga bekräftelsen.**

## 4. Advanced installation

Använd Advanced om du behöver välja interface/IP, extra DNS/FQDN, Avahi/mDNS eller egna data-/backup-sökvägar:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --advanced --lang sv
```

eller:

```bash
bash install.sh --advanced --lang sv
```

Säkerhetsbaslinjen ligger kvar: HTTPS, lokal CA, Simple LAN/IP och host-port 443.

## 5. Efter installationen

Installer/Manager installeras permanent som:

```text
/usr/local/bin/bergahallen-ktm
```

Därför använder du efteråt kommandot utan sökväg till ZIP-katalogen:

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm doctor
sudo bergahallen-ktm verify-meta
```

Serverns normala URL visas av installationen och kan också ses med:

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm tls status
```

Standardinstallationen använder HTTPS på port 443, t.ex.:

```text
https://192.168.1.50
```

## 6. Android-pairing

QR-koden visas automatiskt efter installationen. Om du behöver visa den igen:

```bash
sudo bergahallen-ktm tls pairing-qr
```

Visa Pairing Contract som JSON:

```bash
sudo bergahallen-ktm tls pairing
```

Visa CA-fingerprint:

```bash
sudo bergahallen-ktm tls fingerprint
```

## 7. Installationsrapport

Installeraren skapar:

```text
~/BergaHallen-KTM-Installation.md
```

för den användare som startade installationen via `sudo`. Rapporten innehåller valda sökvägar, serveradress och vanliga Manager-kommandon, men inga lösenord.

## 8. Aktivera Manager Web

Manager CLI är redan installerad. Web Manager är frivillig och aktiveras separat efter en lyckad Server-installation:

```bash
sudo bergahallen-ktm web setup --lang sv
```

Fortsätt med `MANAGER-WEB-SV.md`.

# Vanliga Manager-kommandon

## Hälsa och status

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm doctor
sudo bergahallen-ktm verify-meta
sudo bergahallen-ktm config show
sudo bergahallen-ktm version
sudo bergahallen-ktm paths
```

`doctor` är normalt det första kommandot vid felsökning.

## Start/stop/restart av KTM Server

```bash
sudo bergahallen-ktm start
sudo bergahallen-ktm stop
sudo bergahallen-ktm restart
```

`stop` raderar inte persistent data.

## Loggar

```bash
sudo bergahallen-ktm logs
sudo bergahallen-ktm logs --tail 500
```

## TLS och Android-pairing

```bash
sudo bergahallen-ktm tls status
sudo bergahallen-ktm tls fingerprint
sudo bergahallen-ktm tls pairing
sudo bergahallen-ktm tls pairing-qr
```

Vid DHCP/IP-byte finns ett särskilt reparationskommando som behåller CA/pin och instance UID:

```bash
sudo bergahallen-ktm tls repair-endpoint
```

## Discovery

```bash
sudo bergahallen-ktm discovery status
sudo bergahallen-ktm discovery preferred-url show
sudo bergahallen-ktm discovery avahi status
```

## Manager Web

```bash
sudo bergahallen-ktm web setup --lang sv
sudo bergahallen-ktm web status --lang sv
sudo bergahallen-ktm web restart --lang sv
sudo bergahallen-ktm web password --lang sv
sudo bergahallen-ktm web repair --lang sv
```

## Backup och recovery

Diagnostik:

```bash
sudo bergahallen-ktm recovery diagnose
```

Lista backups:

```bash
sudo bergahallen-ktm recovery backups
```

Skapa backup:

```bash
sudo bergahallen-ktm recovery backup-create
```

Verifiera en backup:

```bash
sudo bergahallen-ktm recovery backup-verify <backupnamn>
```

Visa restore-plan innan mutation:

```bash
sudo bergahallen-ktm recovery restore-plan <backupnamn>
```

Restore kräver explicit bekräftelse och KTM-adminauktorisering:

```bash
sudo bergahallen-ktm recovery restore <backupnamn>
```

## Diagnostikpaket

```bash
sudo bergahallen-ktm recovery diagnostics-bundle
```

Detta skapar ett secrets-fritt support/diagnostikpaket.

## Hjälp

```bash
bergahallen-ktm help
```

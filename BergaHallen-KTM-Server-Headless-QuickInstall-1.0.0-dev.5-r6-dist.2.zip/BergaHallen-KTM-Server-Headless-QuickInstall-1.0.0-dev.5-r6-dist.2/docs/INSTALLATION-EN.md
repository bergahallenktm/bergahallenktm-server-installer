# Installation – Ubuntu Server 24.04 headless

## Requirements

- Ubuntu Server 24.04 LTS
- amd64 / x86-64
- physical Linux server or full VM
- root/sudo access
- LAN connectivity

LXC/CT, Docker/Podman-as-host and other nested container hosts are not officially supported.

## Extract and install

```bash
unzip BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6.zip
cd BergaHallen-KTM-Server-Headless-QuickInstall-1.0.0-dev.5-r6
bash verify-package.sh
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang en
```

Or use:

```bash
bash install.sh --lang en
```

For Advanced setup:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --advanced --lang en
```

The Recommended flow automatically selects the LAN address, provisions/verifies Docker when needed after final confirmation, installs the embedded Server, creates local HTTPS/CA identity, verifies health/meta and displays the Android pairing QR.

After installation the CLI Manager is permanently available as:

```bash
sudo bergahallen-ktm doctor
sudo bergahallen-ktm verify-meta
sudo bergahallen-ktm status
```

Display the Android QR again:

```bash
sudo bergahallen-ktm tls pairing-qr
```

The installation report is written to `~/BergaHallen-KTM-Installation.md` for the sudo-invoking user.

To enable Manager Web, see `MANAGER-WEB-EN.md`.

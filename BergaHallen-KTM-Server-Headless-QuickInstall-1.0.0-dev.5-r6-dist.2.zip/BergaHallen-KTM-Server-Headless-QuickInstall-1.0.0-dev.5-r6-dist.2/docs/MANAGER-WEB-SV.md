# Manager Web – aktivering och användning

BergaHallen KTM har två Manager-gränssnitt:

1. **CLI Manager** – installeras automatiskt som `/usr/local/bin/bergahallen-ktm`.
2. **Manager Web** – frivillig separat HTTPS-tjänst för administration via webbläsare.

Manager Web körs på Linux-hosten och är separat från KTM Server/Webbapp-containern. Manager Web har också **separat inloggning** från KTM Server-admin/player-konton.

## Aktivera Manager Web

Efter att Server-installationen är klar:

```bash
sudo bergahallen-ktm web setup --lang sv
```

Standardvärden:

- scope: `lan`
- port: `3011`
- användare: `manager-admin`
- session: 480 minuter
- HTTPS med separat self-signed Manager Web-certifikat

Du får ange Manager Web-lösenordet två gånger. Det är inte samma lösenord som KTM Server-admin om du inte själv väljer det, och tjänsterna har separata auth-system.

När setup är klar skapas och aktiveras systemd-tjänsten:

```text
bergahallen-ktm-manager-web.service
```

Den aktiveras för autostart.

## Visa adress och status

```bash
sudo bergahallen-ktm web status --lang sv
```

Utdata visar bland annat:

- `active`/`enabled` status;
- port;
- Manager-admin;
- TLS-information;
- TLS SHA-256 fingerprint;
- en eller flera `Web UI:`-adresser.

Öppna den visade adressen från en dator i samma LAN, exempelvis:

```text
https://192.168.1.50:3011
```

Eftersom Manager Web använder ett lokalt self-signed certifikat kan webbläsaren visa en certifikatvarning. Kontrollera SHA-256-fingerprinten mot `web status` innan du fortsätter.

Om värden har en separat brandvägg aktiverad kan TCP/3011 behöva tillåtas från det lokala nätet. Exponera inte Manager Web direkt mot internet.

## Egen port eller localhost-only

Exempel med annan port:

```bash
sudo bergahallen-ktm web setup --port 8443 --lang sv
```

Endast localhost:

```bash
sudo bergahallen-ktm web setup --scope localhost --lang sv
```

Eget Manager-användarnamn:

```bash
sudo bergahallen-ktm web setup --username mitt-managerkonto --lang sv
```

Flaggorna kan kombineras vid första setup.

## Starta/stoppa Manager Web

```bash
sudo bergahallen-ktm web status --lang sv
sudo bergahallen-ktm web stop --lang sv
sudo bergahallen-ktm web start --lang sv
sudo bergahallen-ktm web restart --lang sv
```

Dessa kommandon påverkar **Manager Web-tjänsten**, inte KTM Server.

## Byt Manager Web-lösenord

```bash
sudo bergahallen-ktm web password --lang sv
```

Tjänsten startas om och tidigare webbsessioner blir ogiltiga.

## Reparera Manager Web

Om TLS- eller systemd-material behöver repareras utan att byta Manager-lösenord:

```bash
sudo bergahallen-ktm web repair --lang sv
sudo bergahallen-ktm web status --lang sv
```

## Avahi/mDNS

Avahi är frivilligt och behövs inte för LAN-IP. Första installation av Avahi-publisher via CLI:

```bash
sudo bergahallen-ktm discovery avahi enable --install
```

Status:

```bash
sudo bergahallen-ktm discovery avahi status
```

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BIN="$ROOT/bin/bergahallen-ktm-linux-amd64"

required=(
  "$BIN"
  "$ROOT/release-manifest.json"
  "$ROOT/packaging/docker-sources.json"
  "$ROOT/packaging/release-manifest.json"
  "$ROOT/payload/server-complete/current-server-complete.zip"
)
for f in "${required[@]}"; do
  if [[ ! -f "$f" ]]; then
    echo "ERROR: Paketet är ofullständigt; obligatorisk runtime-fil saknas: ${f#$ROOT/}" >&2
    echo "Packa upp hela ZIP-filen på nytt och kör sedan ./verify-package.sh." >&2
    exit 1
  fi
done

chmod +x "$BIN"

args=("$@")
if [[ ${#args[@]} -eq 0 ]]; then
  args=(--lang sv)
fi

if [[ $(id -u) -eq 0 ]]; then
  exec "$BIN" install "${args[@]}"
fi
if ! command -v sudo >/dev/null 2>&1; then
  echo "ERROR: sudo saknas. Kör som root eller installera sudo." >&2
  exit 1
fi
exec sudo "$BIN" install "${args[@]}"

BergaHallen KTM Server Setup & Manager
Suite 1.0.0-dev.5
Component revision: advanced-install.1-test-r6

This candidate carries the field-verified r5 Installer/Manager UX and integrates Server 1.0.0-dev.5 TEST CANDIDATE r2 for the final CLEAN-INSTALL-FIRST field gate.

After installing this .deb, open "BergaHallen KTM Server Setup & Manager" from the Ubuntu application launcher.

Recommended setup remains beginner-first. Advanced setup remains available and unchanged.
HTTPS, local CA, Simple LAN/IP and host port 443 remain fixed by the security contract.

Supported target: Ubuntu 24.04 amd64 on physical Linux or full VM.
LXC/CT/nested-container targets are not supported.

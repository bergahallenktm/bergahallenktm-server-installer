# START HERE — Installer/Manager 1.0.0-dev.5 advanced-install.1-test-r6

**Status:** FINAL SERVER dev.5 r2 INTEGRATION PREFIELD / NOT CANONICAL

## Recommended clean-install field gate

Swedish:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang sv
```

English:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang en
```

Use a clean Ubuntu 24.04 physical server or full VM. Docker may be absent: Installer/Manager is responsible for provisioning and verifying it after final confirmation.

## Advanced setup

The field-verified r5 Advanced flow remains available and unchanged:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --advanced --lang sv
```

## Integrated Server

Server: `1.0.0-dev.5 TEST CANDIDATE r2`  
Legacy source compatibility: `3.9.14.7.2`  
API: `1`  
DB schema: `21`

Server Full SHA256: `226eddadffe593af4bdba9f7e604691b3c0d33129e71380c575970acfd786633`  
Server Contract SHA256: `dba513b713d905a7af72215703b5bc07dd772c0c49cc932949d94473d11469c5`

See `TESTA-DEV5-FINAL-CLEAN-INSTALL-R6.md`.

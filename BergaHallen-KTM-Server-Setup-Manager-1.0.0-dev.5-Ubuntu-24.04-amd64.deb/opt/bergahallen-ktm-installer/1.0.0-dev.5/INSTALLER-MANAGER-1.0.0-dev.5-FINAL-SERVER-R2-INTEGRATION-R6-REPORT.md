# Installer/Manager dev.5 — Final Server r2 integration r6

Suite: `1.0.0-dev.5`  
Component revision: `advanced-install.1-test-r6`  
Status: `PREFIELD / NOT CANONICAL`

## Accepted field baseline
`advanced-install.1-test-r5` is field verified for Advanced setup, adaptive QR and physical Android pairing.

## r6 change
The embedded Server payload is replaced byte-for-byte with the supplied Server/Webapp `1.0.0-dev.5 TEST CANDIDATE r2` package.

- Server Full SHA256: `226eddadffe593af4bdba9f7e604691b3c0d33129e71380c575970acfd786633`
- Server Contract SHA256: `dba513b713d905a7af72215703b5bc07dd772c0c49cc932949d94473d11469c5`
- Runtime/app version: `1.0.0-dev.5`
- Legacy development/source version: `3.9.14.7.2`
- API: `1`
- DB schema: `21`

Server r2 only hardens its standalone preflight/test harness: missing Docker/Compose/daemon access returns `BLOCKED`. Installer/Manager remains responsible for host Docker provisioning. No TLS State, API, DB or transport contract changes are introduced.

## Required promotion gate
One clean Ubuntu 24.04 CLEAN-INSTALL-FIRST field run with the r6 package must verify:
1. Docker provisioning if absent;
2. Server runtime `1.0.0-dev.5` / schema 21;
3. `doctor` and `verify-meta` PASS;
4. terminal QR renders;
5. physical Android pairing/login succeeds.

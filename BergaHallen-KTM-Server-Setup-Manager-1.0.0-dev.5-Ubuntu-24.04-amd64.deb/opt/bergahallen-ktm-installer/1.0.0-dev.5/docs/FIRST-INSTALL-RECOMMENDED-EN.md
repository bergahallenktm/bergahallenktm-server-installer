# First installation – Recommended setup

This guide is for users with little Linux/server experience.

## You need

- Ubuntu Server 24.04 on a physical computer or full virtual machine;
- the Server connected to the same local network as the phone;
- an account allowed to use `sudo`;
- the Installer package extracted on the Server.

LXC/CT and other nested-container environments are not supported.

## Start

From the Installer directory:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install --lang en
```

Recommended setup normally handles these choices for you:

1. checks that the target is supported;
2. selects the LAN address automatically when there is one unambiguous option;
3. uses HTTPS on the LAN address;
4. reuses compatible Docker or installs what is required;
5. uses the standard `/etc`, `/var/lib`, `/var/backups` and `/var/log` paths;
6. creates the local TLS identity;
7. installs and starts the Server;
8. shows the Server URL;
9. shows a QR code for the Android app.

DNS and mDNS are not required.

## Questions you may see

Recommended setup asks only when it cannot safely decide automatically, for example:

- which LAN to use when the Server has multiple network adapters;
- whether known conflicting Docker packages may be replaced;
- the administrator password;
- final confirmation before system changes begin.

The default administrator username is `admin`.

## After installation

You will see an address such as:

```text
https://192.168.1.229
```

Open the Android app and scan the terminal QR code.

The selected language is saved. Core Manager/TLS commands therefore continue in English after installation and reboot.

Useful checks:

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm doctor
sudo bergahallen-ktm verify-meta
sudo bergahallen-ktm tls status
sudo bergahallen-ktm tls pairing-qr
```

A one-command language override is also available, for example `sudo bergahallen-ktm status --lang sv`.

The installation report in the invoking user's home directory contains the Server address and important paths, but never passwords.

## Advanced setup

For additional technical options:

```bash
sudo bergahallen-ktm install --advanced --lang en
```

The Advanced wizard retains more technical controls. The localization field gate in this revision focuses on Recommended setup and the core post-install Manager/TLS workflow.

## Ubuntu Desktop .deb

Installing the `.deb` installs the setup application; it does not silently start the Server installation. After package installation, open **BergaHallen KTM Server Setup & Manager** from the Ubuntu application launcher. The Desktop setup follows an English Ubuntu locale automatically and includes a Swedish/English language switch.

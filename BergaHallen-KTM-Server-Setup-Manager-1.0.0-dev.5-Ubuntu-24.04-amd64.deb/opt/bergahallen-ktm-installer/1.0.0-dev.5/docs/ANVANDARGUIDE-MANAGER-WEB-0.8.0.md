# Användarguide – Manager Web 0.8.0

Manager Web behåller separat Manager-auth för hostadministration. Recovery-sektionen i 0.8.0 kräver dessutom KTM-adminlösenord när Serverdata ska läsas eller muteras; lösenordet lagras inte av Manager.

## Recovery
- Diagnostik: läser Serverns Recovery Contract v2-status.
- Lista backups: visar Serverns backupkatalog via admin-API.
- Skapa backup: använder Serverns säkra SQLite-backupmekanism.
- Verifiera/plan: kör restore-plan och visar bl.a. schema, instance identity och cross-instance-risk.
- Restore: explicit confirmation; cross-instance har separat starkare confirmation.
- Safe repair: använder Serverns konservativa repair-endpoint.

## Host
Diagnostikpaket och installation repair tillhör Manager/hostnivån. Installation repair ändrar inte aktiv databas, backups, secrets eller serveridentitet.

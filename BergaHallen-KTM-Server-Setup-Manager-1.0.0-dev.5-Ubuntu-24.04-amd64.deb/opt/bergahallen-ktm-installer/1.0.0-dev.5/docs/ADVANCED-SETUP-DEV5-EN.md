# Advanced setup – dev.5

Advanced setup is intended for administrators who need more control than Recommended setup.

Start:

```bash
sudo bergahallen-ktm install --advanced --lang en
```

You may choose:
- exact active LAN interface/IP;
- additional DNS/FQDN as a secondary HTTPS/pairing endpoint;
- Avahi/mDNS discovery;
- Hybrid or Strict Offline;
- supported Docker handling;
- custom persistent data root and backup directory.

The following are locked by the security contract and cannot be disabled:
- HTTPS;
- Installer-owned local CA;
- Simple LAN/IP as primary endpoint;
- host port 443;
- canonical Manager/config/TLS control paths.

The Installer does not create DNS records. If you enter a DNS/FQDN, you must point it to the selected LAN IP. `.local` is reserved for mDNS.

All choices are summarized before you approve system changes.

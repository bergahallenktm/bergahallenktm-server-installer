# Installer 0.8.0 – Recovery Manager architecture

Servern är source of truth för Backup / Restore / Repair v2. Manager är en orkestrator.

Security boundaries:
1. Manager Web-auth krävs för Manager-UI.
2. KTM-adminauth krävs separat för Server recovery APIs.
3. Mutations är POST-only + same-origin + CSRF + serialized.
4. Restore-plan sker före restore.
5. Cross-instance restore kräver separat explicit token.
6. KTM-adminlösenord skrivs inte till manager.json, secrets.env, diagnostikpaket eller loggar.
7. Host repair rör inte aktiv SQLite-data.

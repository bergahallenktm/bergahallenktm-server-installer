# Advanced setup – dev.5

Advanced setup är avsett för administratörer som behöver mer kontroll än Recommended setup.

Start:

```bash
sudo bergahallen-ktm install --advanced --lang sv
```

Du kan välja:
- exakt aktivt LAN-interface/IP;
- extra DNS/FQDN som sekundär HTTPS/pairing-endpoint;
- Avahi/mDNS discovery;
- Hybrid eller Strict Offline;
- stödd Docker-hantering;
- egen persistent data root och backupkatalog.

Följande är låst av säkerhetskontraktet och kan inte stängas av:
- HTTPS;
- Installer-ägd lokal CA;
- Simple LAN/IP som primär endpoint;
- host-port 443;
- canonical Manager/config/TLS-kontrollsökvägar.

Installeraren skapar inte DNS-poster. Om du anger ett DNS/FQDN måste det själv peka mot vald LAN-IP. `.local` reserveras för mDNS.

Alla val sammanfattas innan du godkänner systemändringar.

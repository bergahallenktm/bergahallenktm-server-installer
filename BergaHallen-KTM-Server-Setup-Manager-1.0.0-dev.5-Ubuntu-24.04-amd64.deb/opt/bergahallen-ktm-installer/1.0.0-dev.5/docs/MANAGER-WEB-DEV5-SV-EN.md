# Manager Web – Swedish / English (dev.5)

Manager Web is a separate HTTPS management service. Its administrator account is separate from KTM Server/player accounts.

## English

On an English BergaHallen KTM installation:

```bash
sudo bergahallen-ktm web setup
```

The saved Manager language is used automatically. You can also force English:

```bash
sudo bergahallen-ktm web setup --lang en
```

The password prompts, setup/status output and Manager Web browser UI are English. The selected Web UI language is stored in `/etc/bergahallen-ktm/web-manager.json` as `ui_language` (Web Manager config schema 2).

## Svenska

På en svensk BergaHallen KTM-installation:

```bash
sudo bergahallen-ktm web setup
```

Det sparade Manager-språket används automatiskt. Du kan även tvinga svenska:

```bash
sudo bergahallen-ktm web setup --lang sv
```

Lösenordsfrågor, setup/status och Manager Web i webbläsaren visas på svenska. Språket sparas i `/etc/bergahallen-ktm/web-manager.json` som `ui_language` (Web Manager config schema 2).

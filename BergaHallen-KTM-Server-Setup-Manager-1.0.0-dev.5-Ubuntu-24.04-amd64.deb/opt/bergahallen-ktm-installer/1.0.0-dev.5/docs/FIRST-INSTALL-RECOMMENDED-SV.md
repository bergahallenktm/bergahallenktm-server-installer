# Första installation – Rekommenderad

Den här guiden är avsedd för dig som inte är van vid Linuxservrar.

## Du behöver

- Ubuntu Server 24.04 på en fysisk dator eller full virtuell maskin;
- servern ansluten till samma lokala nätverk som telefonen;
- ett konto som får använda `sudo`;
- Installer-paketet uppackat på servern.

LXC/CT och andra nested-container-miljöer stöds inte.

## Starta

Från Installer-katalogen:

```bash
sudo ./bin/bergahallen-ktm-linux-amd64 install
```

Recommended setup gör normalt följande åt dig:

1. kontrollerar att servern stöds;
2. hittar LAN-adressen automatiskt när det bara finns ett rimligt val;
3. använder HTTPS på LAN-adressen;
4. återanvänder kompatibel Docker eller installerar den som behövs;
5. använder standardkatalogerna under `/etc`, `/var/lib`, `/var/backups` och `/var/log`;
6. skapar lokal TLS-identitet;
7. installerar och startar Servern;
8. visar serveradressen;
9. visar en QR-kod för Android-appen.

Du behöver inte konfigurera DNS eller mDNS.

## Frågor du normalt får

Recommended setup frågar bara när Installer inte säkert kan välja själv, till exempel:

- vilket LAN som ska användas om servern har flera nätverkskort;
- om kända konflikterande Dockerpaket får ersättas;
- administratörslösenord;
- slutlig bekräftelse innan systemet ändras.

Standardadministratören heter `admin`.

## Efter installationen

Du får en adress i stil med:

```text
https://192.168.1.229
```

Öppna Android-appen och skanna terminalens QR-kod.

Valt språk sparas och används som standard även efter installation och omstart.

Vanliga kontroller:

```bash
sudo bergahallen-ktm status
sudo bergahallen-ktm doctor
sudo bergahallen-ktm verify-meta
sudo bergahallen-ktm tls status
sudo bergahallen-ktm tls pairing-qr
```

Språk kan tillfälligt ändras för ett kommando, till exempel `sudo bergahallen-ktm status --lang en`.

Installationsrapporten i användarens hemkatalog innehåller serveradress och viktiga sökvägar men inga lösenord.

## Advanced setup

Behöver du fler tekniska val:

```bash
sudo bergahallen-ktm install --advanced
```

## Ubuntu Desktop .deb

Installationen av `.deb`-paketet installerar själva installationsprogrammet; den startar inte serverinstallationen automatiskt. Efter paketinstallationen öppnar du **BergaHallen KTM Serverinstallation & Manager** från Ubuntus programstartare. Desktop-installationen följer en svensk Ubuntu-locale automatiskt och innehåller språkval för svenska/engelska.

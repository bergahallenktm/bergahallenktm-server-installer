# Delivery Notes — Installer/Manager 1.0.0-dev.5 advanced-install.1-test-r6

## Scope

r6 is an integration-only candidate on top of field-verified r5.

### Changed in r6
- replaced embedded frozen dev.4 Server r2 with Server dev.5 TEST CANDIDATE r2;
- updated Server contract/hash, image/runtime identity and release provenance to dev.5;
- retained API v1, DB schema 21, TLS Contract 2, TLS State schema 2 and Pairing Contract 2;
- retained all field-verified Recommended/Advanced/QR behavior from r5;
- corrected final field evidence naming to r6 rather than the earlier r4/r5 helper lineage.

### Server responsibility boundary
Server r2 does not install Docker. Its standalone test harness reports `BLOCKED` if Docker, Compose or daemon access is missing. Installer/Manager owns host provisioning for the final CLEAN-INSTALL-FIRST workflow.

### Exact integrated artifacts
Server Full SHA256: `226eddadffe593af4bdba9f7e604691b3c0d33129e71380c575970acfd786633`  
Server Contract SHA256: `dba513b713d905a7af72215703b5bc07dd772c0c49cc932949d94473d11469c5`

## Status
`PREFIELD / NOT CANONICAL`
